
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Hello World 출력
		System.out.println("Hello World");
		/*
			C언어 절차지향		함수
			C++	-> class
						
			Java 객체지향		클래스
				호환성, 보안처리
				
			Objective C		iphone	 객체지향
				
			Python, Kotlin	절차 + 객체			
		*/
		
		// 한줄 주석문 : 컴파일이 되지 않는다. 설명
		
		/*
		 	범위 주석문 : 
		 	
		 	HTML : <!-- -->
		 	Python : # """ """ 	
		  
		 */
		 
		/*
		System.out.println("Hello");		
		System.out.println("World");		
		/**/
		System.out.println("안녕하세요");
		
		System.out.print("하이");		
		System.out.println();	// 개행

		System.out.print("만나서 반갑습니다");
		
		// printf	-> format
		System.out.printf("%d %s", 123, "성공을 기원합니다");
		System.out.println();
		
		// escape sequence
		// \n, \t, \", \', \b, \\
		System.out.print("나는 끝까지 노력할 것이다\n");
		System.out.print("성공할\n 때까지\n");
		
		System.out.println("홍길동\t24 서울시");
		System.out.println("박훈\t22 부산시");
		System.out.println("선우태영\t25 강릉시");
		
		System.out.println("\"나는 문제 없어\"");		
		System.out.println("나는 '문'제 없어\b");		
		System.out.println("\\나는 문제 없어\\");
		
	}

}






