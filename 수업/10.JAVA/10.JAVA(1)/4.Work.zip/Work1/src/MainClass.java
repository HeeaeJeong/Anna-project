
public class MainClass {

	public static void main(String[] args) {
		
		String name;
		int age;
		boolean lady;
		String phone;
		double height;
		String address;
		
		System.out.println("==============================================================================");
		System.out.println("\\\tname\tage\tlady\tphone\t\theight\taddress\t\t\\");
		System.out.println("==============================================================================");
		
		name = "홍길동";
		age = 20;
		lady = false;
		phone = "010-111-2222";
		height = 175.12;
		address = "경기도";
		
		System.out.println("\\\t" + name + "\t" + age + "\t" + lady + "\t" + phone + "\t" + height + "\t" + address + "\t\t\\");
		
		name = "일지매";
		age = 18;
		lady = false;
		phone = "02-123-4567";
		height = 180.01;
		address = "서울";
		
		System.out.println("\\\t" + name + "\t" + age + "\t" + lady + "\t" + phone + "\t" + height + "\t" + address + "\t\t\\");
		
		name = "장옥정";
		age = 14;
		lady = true;
		phone = "02-345-7890";
		height = 155.78;
		address = "부산";
				
		System.out.println("\\\t" + name + "\t" + age + "\t" + lady + "\t" + phone + "\t" + height + "\t" + address + "\t\t\\");
		
		System.out.println("==============================================================================");
		
		// 두개의 정수 값을 입력받고 x, y 변수에 저장한 후에 x, y 값을 바꾸고 출력하도록 프로그램을 작성하라. == swap(교환)
		int x, y;
		int temp;
		
		x = 1;
		y = 2;
		
		temp = x;
		x = y;
		y = temp;		
		
		System.out.println("x = " + x + " y = " + y );
		
	}

}








